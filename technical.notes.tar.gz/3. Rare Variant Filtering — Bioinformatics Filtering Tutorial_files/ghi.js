$(document).ready( function(){
  $("div.admonition-download a.external").prettyPhoto({
    theme: 'dark_square'
  })
})

function closePrettyPhoto(){
  $.prettyPhoto.close();
}
