if ( /expansion\.html$/.test(window.location.href)) {
      gIsFrameset = true;
    }
