
/* 
################################################################## 
## 
##   THIS IS A GENERATED FILE. 
## 
##   ANY CHANGES YOU MAKE DIRECTLY TO THIS FILE WILL BE OVERWRITTEN 
##   AND LOST THE NEXT TIME THIS FILE IS GENERATED. 
## 
##  (This file last generated: May 25, 2016, 6:47 A.M.) 
## 
################################################################## 
 */

/* ##### BELOW added by: file:/highwire/webapps/bioinfo/resources/publisher/build/local-js-vars.base.xml ##### */



var gJournalVars = {};



var gJournalVars = {  
  jnlID: 'bioinfo',
   copy: "Oxford University Press",
   issn: '1367-4803',
  eissn: '1460-2059',
  oupcode: 'bioinformatics',
  urlPrefix: 'bioinformatics'
};
 





    var manuscript = false;



 



	var CollapsibleTocs = false;






/* ##### END OF ADDED BLOCK ##### */
