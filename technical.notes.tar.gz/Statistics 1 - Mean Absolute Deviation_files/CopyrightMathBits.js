document.write('<font face="Times New Roman" color="#000000" size="2">Copyright 2000-');
var theDate=new Date();
document.write(theDate.getFullYear());
document.write(' <a href="http://MathBits.com">');
document.write(' MathBits.com</a></font>');
document.write('<br><font face="Times New Roman" color = "#000000" size = "2">All Rights Reserved</font>'); 