window._oiqq = window._oiqq || [];
_oiqq.push(['oiq_addPageCat','Science & Laboratory Industry']);
_oiqq.push(['oiq_doTag']);
_oiqq.push(['oiq_addPageLifecycle', "inte"]);

(function() {
    var oiq = document.createElement('script'); oiq.type = 'text/javascript'; oiq.async = true;
    oiq.src = document.location.protocol + '//px.owneriq.net/stas/s/sholic.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(oiq, s);
})();

(function() {
  var iframe = document.createElement("iframe");
  iframe.setAttribute("src", "//cti.w55c.net/ct/cms-sh2c.html");
  iframe.setAttribute("name", "__dxframe");
  iframe.style.width = "0";
  iframe.style.height = "0";
  iframe.style.border = "0";
  iframe.style.display = "none";

  var handle = setInterval(function() {
    if(!document.body) return;
    clearInterval(handle);
    document.body.appendChild(iframe);
  });
})();
var _comscore = _comscore || [];
_comscore.push({ c1: "7", c2: "19376307" ,c3: "1" });
(function() {
  var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true;
  s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
  el.parentNode.insertBefore(s, el);
})();
